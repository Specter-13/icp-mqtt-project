ICP projekt - varianta 1: MQTT explorer/dashboard

Grafická aplikace sloužící jako klient pro sledování MQTT komunikace.

Autoři:
 - Vojtěch Jurka (xjurka08)
 - Dávid Špavor (xspavo00)
 
Omezení:
Zadání je implementováno kompletně kromě následujících omezení:
 - nebyla implementována historie zpráv ve stromové struktuře a zabarvení odeslaných zpráv
 - nelze přeložit na referenčním stroji, jelikož projekt používá QT MQTT knihovnu, nikoli paho (překlad bude předveden na vlastním počítači)

Verze QT - 5.9.9
Verze QT MQTT - 5.15.0
